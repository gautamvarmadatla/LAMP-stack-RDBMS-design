<?php
$server = "localhost:3307";
$username = "root";
$password = "";
$dbname = "company_db";

$conn = mysqli_connect($server, $username, $password, $dbname);
if(!$conn){
    echo "Error to connect DB!";
}
else{
    echo "Connection good!";
}


if(isset($_POST['submit']))
    {
    $project_no = $_POST['project_no'];
    $proj_date_started = $_POST['proj_date_started'];
    $proj_date_ended = $_POST['proj_date_ended'];
    $proj_budget = $_POST['proj_budget'];
    $proj_manager_emp_no = $_POST['proj_manager_emp_no'];
	$dept_name = $_POST['dept_name'];
    $emp_no = $_POST['emp_no'];
	$emp_proj_role = $_POST['emp_proj_role'];
	$time_spent_months = $_POST['time_spent_months'];
   

    $query = " UPDATE project SET proj_date_started='$proj_date_started', proj_date_ended='$proj_date_ended', proj_budget='$proj_budget', proj_manager_emp_no='$proj_manager_emp_no' WHERE  project_no='$project_no' ";
	$query2 = " UPDATE emp_proj_history SET emp_proj_role='$emp_proj_role' , time_spent_months='$time_spent_months' WHERE emp_no='$emp_no' AND 'proj_no=$project_no' ";
	
	
	$run = mysqli_query($conn,$query);
	$run = mysqli_query($conn,$query2);

    if($run){
        echo "<script type='text/javascript'>alert('Successfully Modified!'); window.location.href='index.html';</script>";
    }
    else{
        echo "Error: " . $query . "<br>" . mysqli_error($conn);
    }

}
else{
    echo "Hello";
}
?>