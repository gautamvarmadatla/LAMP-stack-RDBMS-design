<?php
$server = "localhost:3307";
$username = "root";
$password = "";
$dbname = "company_db";

$conn = mysqli_connect($server, $username, $password, $dbname);

if(isset($_POST['submit']))
    {
    $emp_id = $_POST['emp_id'];

    $query = "DELETE FROM temp_employee WHERE emp_id  = '$emp_id'";

    $run = mysqli_query($conn,$query);

    if($run){
        echo "<script type='text/javascript'>alert('Successfully Deleted!'); window.location.href='index.html';</script>";
    }
    else{
        echo "Error: " . $query . "<br>" . mysqli_error($conn);
    }

}

?> 	