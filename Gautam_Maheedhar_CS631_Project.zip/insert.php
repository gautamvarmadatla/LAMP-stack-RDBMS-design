

<?php
$server = "localhost:3307";
$username = "root";
$password = "";
$dbname = "company_db";

$conn = mysqli_connect($server, $username, $password, $dbname);
if(!$conn){
    echo "Error to connect DB!";
}
else{
    echo "Connection good!";
}


if(isset($_POST['submit']))
    {
		echo '<script type="text/javascript">alert("Php working")</script>';
    $emp_no = $_POST['emp_no'];
    $emp_name = $_POST['emp_name'];
    $emp_personal_no = $_POST['emp_personal_no'];
    $emp_curr_job_id = $_POST['emp_curr_job_id'];
    $emp_curr_proj_id = $_POST['emp_curr_proj_id'];
    $emp_dept_name = $_POST['emp_dept_name'];
    $emp_room_no = $_POST['emp_room_no'];
    $emp_build_no = $_POST['emp_build_no'];
	
	
	$emp_proj_role = $_POST['emp_proj_role'];
	$time_spent_months = $_POST['time_spent_months'];
	
	$emp_job_title =$_POST['emp_job_title'];
	$job_date_started =$_POST['job_date_started'];
	$emp_job_salary =$_POST['emp_job_salary'];


    $query = "INSERT INTO company_db.employee VALUES ('$emp_no', '$emp_name','$emp_personal_no','$emp_curr_job_id', '$emp_curr_proj_id','$emp_dept_name','$emp_room_no' , '$emp_build_no')";
    $query2 = "INSERT INTO emp_proj_history VALUES ('$emp_no' , '$emp_curr_proj_id' , '$emp_proj_role' , '$time_spent_months')";
    $query3 = "INSERT INTO emp_job_history VALUES ('$emp_no' , '$emp_curr_job_id' , '$emp_job_title' , '$job_date_started' , '$emp_job_salary')";
    $run = mysqli_query($conn,$query);
	$run = mysqli_query($conn,$query2);
	$run = mysqli_query($conn,$query3);
	if($run)
	{
		echo '< script type="text/javascript">alert("Values inserted successfully")</script>';
	}

    #echo "<script type='text/javascript'>alert('$run'); window.location.href=\"create.php\";</script>";


    if($run){
        echo "<script type='text/javascript'>alert('Successfully Inserted!'); window.location.href=\"index.html\";</script>";
    }
    else{
        echo "Error: " . $query . "<br>" . mysqli_error($conn);
    }


    }
?>