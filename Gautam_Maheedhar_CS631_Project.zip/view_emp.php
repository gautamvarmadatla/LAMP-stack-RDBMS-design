<!DOCTYPE html>
<html>
<link rel="stylesheet" href="style4.css">
<header>
<center><h1>Employee details</h1></center>
</header>
<center>

<table border="2", padding="12px 18px", width="75%", display="inline-block">
  <tr>
    <td><center>Employee Number</center></td>
    <td><center>Employee Name </center></td>
    <td><center>Personal Number</center></td>
	<td><center>Current Job ID</center></td>
	<td><center>Current Project ID </center></td>
	<td><center>Department Name</center></td>
	<td><center>Office Room Number</center></td>
	<td><center>Building Number</center></td>
  
  </tr>
  



<?php

$server = "localhost:3307";
$username = "root";
$password = "";
$dbname = "company_db";

$conn = mysqli_connect($server, $username, $password, $dbname);


$records = mysqli_query($conn,"SELECT * FROM employee"); 
while($data = mysqli_fetch_array($records))
{
?>
  <tr>
    <td><center><?php echo $data['emp_no']; ?></center></td>
    <td><center><?php echo $data['emp_name']; ?></center></td>
    <td><center><?php echo $data['emp_personal_no']; ?></center></td>
    <td><center><?php echo $data['emp_curr_job_id']; ?></center></td>
	<td><center><?php echo $data['emp_curr_proj_id']; ?></center></td>
	<td><center><?php echo $data['emp_dept_name']; ?></center></td>
	<td><center><?php echo $data['emp_room_no']; ?></center></td>
	<td><center><?php echo $data['emp_build_no']; ?></center></td>
  </tr> <br>
  
<?php
}
?>
 

</table>


</body>
</html>