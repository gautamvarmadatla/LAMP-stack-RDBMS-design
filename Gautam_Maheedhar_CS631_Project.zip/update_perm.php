<!DOCTYPE html>
<html>
<link rel="stylesheet" href="style4.css">
<body>
    <center><h1> Update Permanant employee details</h1><br><br><br><br><br>

    <form action="modify_perm_emp.php" method="POST">
    <label for="emp_no"><b>Employee Number</b></label>
    <input type="number" placeholder="Enter employee number" name="emp_no" required> <br> <br>
   
    <label for="emp_name"><b>Employee Name</b></label>
    <input type="text" placeholder="Enter employee's name" name="emp_name"> <br> <br>
    
	<label for="emp_personal_no"><b> Employee personal number </b></label>
    <input type="tele" placeholder="Enter phone number" name="emp_personal_no" > <br> <br>
   
	<label for="emp_dept_name"><b>Employee department name</b></label>
    <input type="text" placeholder="Enter associated department" name="emp_dept_name" > <br> <br>
	
	<label for="emp_room_no"><b>Employee Room Number</b></label>
    <input type="number" placeholder="Enter employee's office room number" name="emp_room_no"> <br> <br>
	
	<label for="emp_build_no"><b>Employee Building Number</b></label>
    <input type="number" placeholder="Enter employee's building number" name="emp_build_no" > <br> <br> <br>
            
		
	 <center><h3> Project related details</h3>
	<label for="proj_no"><b>Employee project number</b></label>
    <input type="number" placeholder="Enter associated department" name="proj_no" required> <br> <br>
	
	<label for="emp_proj_role"><b>Employee Project Role </b></label>
    <input type="text" placeholder="Enter associated department" name="emp_proj_role" > <br> <br>
	
	<label for="temp_spent_months"><b>Enter time spent on project ( Months)</b></label>
    <input type="number" placeholder="Enter associated department" name="time_spent_months" > <br> <br>
	
	<center><h3> Job history related details</h3>
	<label for="job_id"><b>Employee JOB ID </b></label>
    <input type="number" placeholder="Enter associated Job ID" name="job_id" required> <br> <br>
	
	<label for="emp_job_title"><b>Employee job title </b></label>
    <input type="text" placeholder="Enter job title" name="emp_job_title" > <br> <br>
	
	
	<label for="job_date_started"><b>Job start date </b></label>
    <input type="date" placeholder="Enter job start date" name="job_date_started" > <br> <br>
	
	

	<label for="emp_job_salary"><b>Job salary </b></label>
    <input type="number" placeholder="Enter associated job salary" name="emp_job_salary" > <br> <br>
	

			<div class="clearfix">
            <button class="button" type="button" onclick="window.location.href='index.html'" class="cancelbtn"><b> Cancel </b> </button>
            <button class="button" type="submit" name="submit"><b> Submit </b> </button>
        </div>	
        </div>
    </form>
</center>
    
</body>

</html>