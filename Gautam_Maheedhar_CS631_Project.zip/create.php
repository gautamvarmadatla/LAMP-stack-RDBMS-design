<!DOCTYPE html>
<html>

<body>
    <style>
      .button {
  background-color: #000000;
  border: none;
  color: white;
  padding: 20px;
  text-align: center;
  text-decoration: none;
  display: inline-block;
  font-size: 16px;
  margin: 4px 2px;
}
    </style>


    <center><h2 style="font-family: 'Courier New';">Add employee</h2><br><br><br><br><br>

    <form action="insert.php" method="POST">
    <label for="emp_no"><b>Employee Number</b></label>
    <input type="text" placeholder="Enter employee's number" name="emp_no" required> <br> <br>
    <label for="emp_name"><b>Employee Name</b></label>
    <input type="text" placeholder="Enter employee's name" name="emp_name" required> <br> <br>
    <label for="emp_personal_no"><b> Employee Personal Number </b></label>
    <input type="tel" name="emp_personal_no" id="emp_personal_no" placeholder="Enter customer phone number" name="emp_personal_no" required> <br> <br>
    <label for="emp_curr_job_id"><b>Current Job no</b></label>
    <input type="number" placeholder="Enter employee's current job ID" name="emp_curr_job_id" required> <br> <br>
    <label for="emp_curr_proj_id"><b>Current Project </b></label>
    <input type="number" placeholder="Enter employee's current project ID" name="emp_curr_proj_id" required> <br> <br>

    <label for="emp_dept_name"><b>Department Name</b></label>
    <input type="text" placeholder="Enter employee's department" name="emp_dept_name" required> <br> <br>

    <label for="emp_room_no"><b>Office room No</b></label>
    <input type="number" placeholder="Enter employee's office room number " name="emp_room_no" required> <br> <br>

    <label for="emp_build_no"><b>Building Number</b></label>
    <input type="number" placeholder="Enter employee's building number" name="emp_build_no" required> <br> <br>
	
		 <center><h3> Project related details</h3>
		 
	
	<label for="emp_proj_role"><b>Employee Project Role </b></label>
    <input type="text" placeholder="Enter associated department" name="emp_proj_role" > <br> <br>
	
	<label for="temp_spent_months"><b>Enter time spent on project ( Months)</b></label>
    <input type="number" placeholder="Enter associated department" name="time_spent_months" > <br> <br>
	
	
		 <center><h3> JOB related details</h3>
	
	<label for="emp_job_title"><b>Employee job title </b></label>
    <input type="text" placeholder="Enter job title" name="emp_job_title" > <br> <br>
	
	<label for="job_date_started"><b>Job start date</b></label>
    <input type="date" placeholder="Enter job start date" name="job_date_started" > <br> <br>
	
	<label for="emp_job_salary"><b>Job salary (Annual)</b></label>
    <input type="number" placeholder="Enter associated job salary" name="emp_job_salary" > <br> <br>
	
	
	
	



              <div class="clearfix">
            <button class="button" type="button" onclick="window.location.href='index.html'" class="cancelbtn"><b> Cancel </b> </button>
            <button class="button" type="submit" name="submit"><b> Submit </b> </button>
        </div>
        </div>
    </form>
</center>
    
</body>

</html>