<!DOCTYPE html>
<html>
<link rel="stylesheet" href="style5.css">
<body>
    <center><h1> Update Temporary employee details</h1><br><br><br><br><br>

    <form action="modify_temp_emp.php" method="POST">
    <label for="emp_id"><b>Employee ID</b></label>
    <input type="number" placeholder="Enter employee ID" name="emp_id" required> <br> <br>
   
    <label for="emp_name"><b>Employee Name</b></label>
    <input type="text" placeholder="Enter employee's name" name="emp_name" required> <br> <br>
    
	<label for="hours_worked"><b> Hours Worked </b></label>
    <input type="tele" placeholder="Enter hours worked" name="hours_worked" required> <br> <br>
   
    <label for="proj_no"><b>Project number</b></label>
    <input type="number" placeholder="Enter employe's current project no " name="proj_no" required> <br> <br>
    
	<label for="payperhour"><b>Pay per Hour</b></label>
    <input type="number" placeholder="Enter employee's pay per hour" name="payperhour" required> <br> <br>

            <div class="clearfix">
            <button class="button" type="button" onclick="window.location.href='index.html'" class="cancelbtn"><b> Cancel </b> </button>
            <button class="button" type="submit" name="submit"><b> Submit </b> </button>
        </div>
        </div>
    </form>
</center>
    
</body>

</html>