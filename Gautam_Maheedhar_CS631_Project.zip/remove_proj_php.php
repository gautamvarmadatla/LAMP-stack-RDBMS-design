<?php
$server = "localhost:3307";
$username = "root";
$password = "";
$dbname = "company_db";

$conn = mysqli_connect($server, $username, $password, $dbname);

if(isset($_POST['submit']))
    {
    $proj_no = $_POST['proj_no'];

    $query = "DELETE FROM project WHERE proj_no  = '$proj_no'";
	$query2 = "DELETE FROM dept_proj_history WHERE proj_no = '$proj_no'";
	$query3 = "DELETE FROM emp_proj_history WHERE proj_no='$proj_no'";
	

    $run = mysqli_query($conn,$query);
	$run = mysqli_query($conn,$query2);
	$run = mysqli_query($conn,$query3);

    if($run){
        echo "<script type='text/javascript'>alert('Successfully Deleted!'); window.location.href='index.html';</script>";
    }
    else{
        echo "Error: " . $query . "<br>" . mysqli_error($conn);
    }

}
else{
    echo "Hello";
}
?>