<!DOCTYPE html>
<html>
<body>
    <center><h2>Add temporary employee</h2><br><br><br><br><br>
    <form action="create_temp_php.php" method="POST">
    <label for="emp_id"><b>emp_id</b></label>
    <input type="number" placeholder="Enter employee's id" name="emp_id" required> <br> <br>
    <label for="emp_name"><b>emp_name</b></label>
    <input type="text" placeholder="Enter employee's name" name="emp_name" required> <br> <br>
    <label for="hours_worked"><b> hours_worked </b></label>
    <input type="number" name="hours_worked" id="hours_worked" placeholder="Enter Hours worked" name="hours_worked" required> <br> <br>
    <label for="pay per hour"><b>pay per hour</b></label>
    <input type="number" placeholder="Enter employee's pay per hour" name="pay per hour" required> <br> <br>
    <label for="proj_no"><b>proj_no</b></label>
    <input type="number" placeholder="Enter employee's current project ID" name="proj_no" required> <br> <br>

              <div class="clearfix">
            <button class="button" type="button" onclick="window.location.href='index.html'" class="cancelbtn"><b> Cancel </b> </button>
            <button class="button" type="submit" name="submit"><b> Submit </b> </button>
        </div>
        </div>
    </form>
</center>
</body>
</html>