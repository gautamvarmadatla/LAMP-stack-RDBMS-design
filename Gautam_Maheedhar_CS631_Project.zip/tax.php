

<!DOCTYPE html>
<html>
<center>
<link rel="stylesheet" href="style5.css">
<table border="1", padding="12px 18px", width="50%", display="inline-block">
  <tr>
    <td><center><b>Employee Number</center></b></td>
    <td><center><b>Salary (per annum) </center></b></td>
    <td><center><b>Federal Tax (10%)</center></b></td>
    <td><center><b>State Tax (5%)</center></b></td>
	<td><center><b>Other Taxes (3%)<center></b></td>
	<td><center><b> Total Taxes </center></b></td>
	<td><center><b> Employee salary after tax deduction </center></b></td>
  
  </tr>
  



<?php

$server = "localhost:3307";
$username = "root";
$password = "";
$dbname = "company_db";

$conn = mysqli_connect($server, $username, $password, $dbname);


$records = mysqli_query($conn,"SELECT emp_no,emp_job_salary,0.1*emp_job_salary AS federal_tax, 0.05*emp_job_salary AS state_tax , 0.03*emp_job_salary AS other_tax , 
0.1*emp_job_salary + 0.05*emp_job_salary + 0.03*emp_job_salary as total_tax ,
emp_job_salary - 0.153*emp_job_salary AS sal FROM emp_job_history GROUP BY emp_no"); 
while($data = mysqli_fetch_array($records))
{
?>
  <tr>
    <td><center><?php echo $data['emp_no']; ?></center></td>
    <td><center><?php echo $data['emp_job_salary']; ?></center></td>
    <td><center><?php echo $data['federal_tax']; ?></center></td>
    <td><center><?php echo $data['state_tax']; ?></center></td>
	<td><center><?php echo $data['other_tax']; ?></center></td>
	<td><center><?php echo $data['total_tax']; ?></center></td>
	<td><center><?php echo $data['sal']; ?></center></td>
  </tr> <br>
  
<?php
}
?>



<br><br><br><br>


<table border="2", padding="12px 18px", width="75%", display="inline-block">
  <tr>
    <td><center><b>Employee id</center></b></td>
	 <td><center><b>Employee Name </center></b></td>
    <td><center><b>Number of hours worked (Per Month) </center></b></td>
    <td><center><b>Salary Per Hour</center></b></td>
	<td><center><b>Total Pay per month</center></b></td>
	<td><center><b>Federal Tax (5%)</center></b></td>
    <td><center><b>State Tax (5%)</center></b></td>
	<td><center><b>Other Taxes (3%)<center></b></td>
	<td><center><b>Total Taxes </center></b></td>
	<td><center><b>Employee salary after tax deduction </center></b></td>
  
  </tr>
  <header>
  <h3>Permanant employees salary and tax report</h3></header>


<?php

$server = "localhost:3307";
$username = "root";
$password = "";
$dbname = "company_db";

$conn = mysqli_connect($server, $username, $password, $dbname);


$records = mysqli_query($conn,"SELECT emp_id , emp_name , hours_worked , payperhour , hours_worked*payperhour AS total_pay , 0.1*hours_worked*payperhour AS federal_tax, 0.05*hours_worked*payperhour AS state_tax , 0.03*hours_worked*payperhour AS other_tax , 
0.1*hours_worked*payperhour + 0.05*hours_worked*payperhour + 0.03*hours_worked*payperhour as total_tax ,
hours_worked*payperhour - 0.153*hours_worked*payperhour AS sal FROM temp_employee"); 
while($data = mysqli_fetch_array($records))
{
?>
  <tr>
    <td><center><?php echo $data['emp_id']; ?></center></td>
    <td><center><?php echo $data['emp_name']; ?></center></td>
	<td><center><?php echo $data['hours_worked']; ?></center></td>
	<td><center><?php echo $data['payperhour']; ?></center></td>
	<td><center><?php echo $data['total_pay']; ?></center></td>
	<td><center><?php echo $data['federal_tax']; ?></center></td>
    <td><center><?php echo $data['state_tax']; ?></center></td>
	<td><center><?php echo $data['other_tax']; ?></center></td>
	<td><center><?php echo $data['total_tax']; ?></center></td>
	<td><center><?php echo $data['sal']; ?></center></td>
  </tr> <br>
  

<?php
}
?>
 

</table>
<header>
 <h3>Temporary employees salary and tax report</h3> 
</header>

</body>
</html>