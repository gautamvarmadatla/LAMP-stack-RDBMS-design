

<!DOCTYPE html>
<html>
<link rel="stylesheet" href="style4.css">
<header>
<center><h1>Employee Related Project Statistics</h1></center></header><br><br><br><br><br>
<center>

<table border="2", padding="12px 18px", width="100%", display="inline-block">
  <tr>
    <td><center><b>Project Number</b></center></td>
    <td><center><b>Employee number </b></center></td>
    <td><center><b>Employee Project Role</b></center></td>
    <td><center><b>Time Spent(Months)</b></center></td>
  
  </tr>
  



<?php

$server = "localhost:3307";
$username = "root";
$password = "";
$dbname = "company_db";

$conn = mysqli_connect($server, $username, $password, $dbname);


$records = mysqli_query($conn,"SELECT * FROM emp_proj_history"); 
while($data = mysqli_fetch_array($records))
{
?>
  <tr>
    <td><center><?php echo $data['emp_no']; ?></center></td>
    <td><center><?php echo $data['proj_no']; ?></center></td>
    <td><center><?php echo $data['emp_proj_role']; ?></center></td>
    <td><center><?php echo $data['time_spent_months']; ?></center></td>
  </tr> <br>
  
<?php
}
?>
 

</table>


</body>
</html>