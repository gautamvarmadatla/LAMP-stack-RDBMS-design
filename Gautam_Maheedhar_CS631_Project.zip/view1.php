<!DOCTYPE html>
<html>
<link rel="stylesheet" href="style3.css">
<style>
    .button {
  background-color: #000000;
  border: none;
  color: white;
  padding: 20px;
  text-align: center;
  text-decoration: none;
  display: inline-block;
  font-size: 16px;
  margin: 4px 2px;
  
  

}


.button {border-radius: 12px;}
    }	
  </style>


<header>
<center><h1>Best-P Personel Project statistics</center></h1><br><br><br><br><br>
</header>
<center>
<form action="view1_php.php" method = "POST">
<div class="clearfix">
    
        <button class=button type="submit" name = "submit" class="signupbtn"><b> View Overall Project statistics </b> </button><br><br><br>
		    
			
      </div>
</div>

</form> 

<button class="button"  onclick="window.location.href='view1_e.php'"> <b>Employee related project statistics</b></button><br><br><br>
<button class="button"  onclick="window.location.href='view1_d.php'"> <b>Department related project statistics</b></button><br><br><br>
<button class=button type="button" onclick="window.location.href='index.html'" class="cancelbtn"><b> Cancel </b> </button>
</body>
</html>

