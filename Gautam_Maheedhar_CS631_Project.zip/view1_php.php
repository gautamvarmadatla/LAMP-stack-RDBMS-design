

<!DOCTYPE html>
<html>

<link rel="stylesheet" href="style4.css">
<header>
<center><h1>Overall Project statistics</h1></center></header><br><br><br><br><br>
<center>

<table border="2", padding="12px 18px", width="100%", display="inline-block">
  <tr>
    <td><center><b>Project Number</center></b></td>
    <td><center><b>Start Date</center></b></td>
    <td><center><b>End Date</center></b></td>
    <td><center><b>Budget</center></b></td>
    <td><center><b>Manager employee number</center></b></td>
  </tr>
  



<?php

$server = "localhost:3307";
$username = "root";
$password = "";
$dbname = "company_db";

$conn = mysqli_connect($server, $username, $password, $dbname);


$records = mysqli_query($conn,"SELECT * FROM project"); 
while($data = mysqli_fetch_array($records))
{
?>
  <tr>
    <td><center><?php echo $data['project_no']; ?></center></td>
    <td><center><?php echo $data['proj_date_started']; ?></center></td>
    <td><center><?php echo $data['proj_date_ended']; ?></center></td>
    <td><center><?php echo $data['proj_budget']; ?></center></td>
    <td><center><?php echo $data['proj_manager_emp_no']; ?></center></td> 
  </tr> <br>
  
<?php
}
?>
 
</table>

<br><br><br><br>

<table border="2", padding="12px 18px", width="50%", display="inline-block">
	<tr>
		<td><center><b>Project Number</center></b></td>
		<td> <center><b>Number of employees under project</center></b></td>
	</tr>
	
<?php
$server = "localhost:3307";
$username = "root";
$password = "";
$dbname = "company_db";


$conn = mysqli_connect($server , $username , $password , $dbname);
$records = mysqli_query($conn , "SELECT proj_no , COUNT(emp_no) FROM emp_proj_history GROUP BY proj_no");

while($data = mysqli_fetch_array($records))
{
?>
  <tr>
    <td><center><?php echo $data['proj_no']; ?></center></td>
    <td><center><?php echo $data['COUNT(emp_no)']; ?></center></td>
  </tr> <br>
  
<?php
}
?>

</table>


</body>
</html>