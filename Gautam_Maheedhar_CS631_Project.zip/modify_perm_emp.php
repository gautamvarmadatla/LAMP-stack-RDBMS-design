<?php
$server = "localhost:3307";
$username = "root";
$password = "";
$dbname = "company_db";

$conn = mysqli_connect($server, $username, $password, $dbname);
if(!$conn){
    echo "Error to connect DB!";
}
else{
    echo "Connection good!";
}


if(isset($_POST['submit']))
    {
    $emp_no = $_POST['emp_no'];
    $emp_name = $_POST['emp_name'];
    $emp_personal_no = $_POST['emp_personal_no'];
	$emp_dept_name = $_POST['emp_dept_name'];
    $emp_room_no = $_POST['emp_room_no'];
	$emp_build_no = $_POST['emp_build_no'];
	$proj_no = $_POST['proj_no'];
	$emp_proj_role = $_POST['emp_proj_role'];
	$time_spent_months = $_POST['time_spent_months'];	
	$job_id = $_POST['job_id'];
	$emp_job_title =$_POST['emp_job_title'];
	$job_date_started =$_POST['job_date_started'];
	$emp_job_salary =$_POST['emp_job_salary'];
	
   

    $query = " UPDATE employee SET emp_name='$emp_name', emp_personal_no='$emp_personal_no', emp_dept_name='$emp_dept_name', emp_room_no='$emp_room_no' , emp_build_no='$emp_build_no' WHERE  emp_no='$emp_no' ";
    $query2 = " UPDATE emp_proj_history SET emp_proj_role='$emp_proj_role' , time_spent_months='$time_spent_months' WHERE emp_no='$emp_no' AND proj_no='$proj_no' ";
	$query3 = "UPDATE emp_job_history SET emp_job_title='$emp_job_title' , job_date_started='$job_date_started' , emp_job_salary='$emp_job_salary' WHERE emp_no='$emp_no' AND job_id='$job_id' ";
	
	
	$run = mysqli_query($conn,$query);
    $run = mysqli_query($conn,$query2);
	$run = mysqli_query($conn,$query3);
	

    if($run){
        echo "<script type='text/javascript'>alert('Successfully Modified!'); window.location.href='index.html';</script>";
    }
    else{
        echo "Error: " . $query . "<br>" . mysqli_error($conn);
    }

}
else{
    echo "Hello";
}
?>