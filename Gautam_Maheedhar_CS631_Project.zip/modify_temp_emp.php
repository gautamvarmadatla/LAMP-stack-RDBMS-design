<?php
$server = "localhost:3307";
$username = "root";
$password = "";
$dbname = "company_db";
$conn = mysqli_connect($server, $username, $password, $dbname);
if(isset($_POST['submit']))
    {
    $emp_no = $_POST['emp_no'];
    $emp_name = $_POST['emp_name'];
    $emp_personal_no = $_POST['emp_personal_no'];
    $emp_curr_job_id = $_POST['emp_curr_job_id'];
    $emp_curr_proj_id = $_POST['emp_curr_proj_id'];
	$emp_dept_name = $_POST['emp_dept_name'];
    $emp_room_no = $_POST['emp_room_no'];
	$emp_build_no = $_POST['emp_build_no'];
   

    $query = " UPDATE employee SET emp_name='$emp_name', emp_personal_no='$emp_personal_no', emp_curr_job_id='$emp_curr_job_id', emp_curr_proj_id='$emp_curr_proj_id' , emp_dept_name='$emp_dept_name', emp_room_no='$emp_room_no' , emp_build_no='$emp_build_no' WHERE  emp_no='$emp_no' ";

	
	$run = mysqli_query($conn,$query);

	

    if($run){
        echo "<script type='text/javascript'>alert('Successfully Modified!'); window.location.href='index.html';</script>";
    }
    else{
        echo "Error: " . $query . "<br>" . mysqli_error($conn);
    }

}

?>