

<?php
$server = "localhost:3307";
$username = "root";
$password = "";
$dbname = "company_db";
$conn = mysqli_connect($server, $username, $password, $dbname);
if(isset($_POST['submit']))
    {
    $emp_id = $_POST['emp_id'];
    $emp_name = $_POST['emp_name'];
    $hours_worked = $_POST['hours_worked'];
    $payperhour = $_POST['payperhour'];
    $proj_no = $_POST['proj_no'];


    $query = "INSERT INTO company_db.temp_employee VALUES ('$emp_id', '$emp_name','$hours_worked','$proj_no','$payperhour')";

  
    $run = mysqli_query($conn,$query);

    if($run){
        echo "<script type='text/javascript'>alert('Successfully Inserted!'); window.location.href=\"index.html\";</script>";
    }
    else{
        echo "Error: " . $query . "<br>" . mysqli_error($conn);
    }


    }
?>