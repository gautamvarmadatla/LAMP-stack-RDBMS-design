<!DOCTYPE html>
<html>
<link rel="stylesheet" href="style3.css">
<body>
    <style>
        .button {
  background-color: #000000;
  border: none;
  color: white;
  padding: 20px;
  text-align: center;
  text-decoration: none;
  display: inline-block;
  font-size: 16px;
  margin: 4px 2px;
}
    </style>

    <header>
    <center><h1>Best-P Personnel Update Project Details</h1></center><br><br><br><br><br></header>
	<center>

    <form action="modify1.php" method="POST">
    <label for="project_no"><b>project_no</b></label>
    <input type="number" placeholder="Enter project number" name="project_no" required> <br> <br>
   
    <label for="proj_date_started"><b>proj_date_started</b></label>
    <input type="date" placeholder="Enter projects's start date" name="proj_date_started" required> <br> <br>
    
	<label for="proj_date_ended"><b> proj_date_ended </b></label>
    <input type="date" placeholder="Enter project's end date" name="proj_date_ended" required> <br> <br>
   
    <label for="proj_budget"><b>proj_budget</b></label>
    <input type="number" placeholder="Enter project budget" name="proj_budget" required> <br> <br>
    
	<label for="proj_manager_emp_no"><b>proj_manager_emp_no</b></label>
    <input type="number" placeholder="Enter current project manager's employee number" name="proj_manager_emp_no" required> <br> <br>
	
	<label for="dept_name"><b>dept_name</b></label>
    <input type="text" placeholder="Enter associated department" name="dept_name" required> <br> <br><br><br>

	
    <center><h3 style="font-family: 'Courier New';">Update employees associated with project </h3><br><br>
	
	<label for="emp_no"><b>emp_no</b></label>
    <input type="number" placeholder="Enter employee number" name="emp_no" required> <br> <br>
	
	<label for="emp_proj_role"><b>emp_proj_role</b></label>
    <input type="text" placeholder="Enter employee's project role" name="emp_proj_role" required> <br> <br>
	
	<labe for="time_spent_months"><b>time_spent_months</b></label>
	<input type="number" placeholder="Enter time spent in months" name="time_spent_months" required <br> <br> <br> <br> <br>
	
	




              <div class="clearfix">
            <button class="button" type="button" onclick="window.location.href='index.html'" class="cancelbtn"><b> Cancel </b> </button>
            <button class="button" type="submit" name="submit"><b> Submit </b> </button>
        </div>
        </div>
    </form>
</center>
    
</body>

</html>