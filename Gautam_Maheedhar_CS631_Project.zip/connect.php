<?php
$server = "localhost";
$username = "root";
$password = "Asdlkjpo1!";
$dbname = "company_db";

$conn = mysqli_connect($server, $username, $password, $dbname);
if(!$conn){
    echo "Error to connect DB!";
}
else{
    echo "Connection good!";
}
?>