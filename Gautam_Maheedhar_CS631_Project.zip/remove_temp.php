<!DOCTYPE html>
<html>
<body>

<center><h2>Remove temporary employee</h2><br><br><br><br><br><br>

<form action="remove_temp_php.php" method = "POST">
	<label for="emp_id"><b>Employee Number</b></label>
      <input type="text" placeholder="Enter employee ID" name="emp_id" required> <br> <br> <br><br>
      
      <div class="clearfix">
        <button class=button type="button" onclick="window.location.href='index.html'" class="cancelbtn"><b> Cancel </b> </button>
        <button class=button type="submit" name = "submit" class="signupbtn"><b> Remove </b> </button>
      </div>
</div>
</form>
</center> 
</body>
</html>