

<?php
$server = "localhost:3307";
$username = "root";
$password = "";
$dbname = "company_db";

$conn = mysqli_connect($server, $username, $password, $dbname);
if(!$conn){
    echo "Error to connect DB!";
}
else{
    echo "Connection good!";
}


if(isset($_POST['submit']))
    {
    $project_no = $_POST['project_no'];
    $proj_date_started = $_POST['proj_date_started'];
    $proj_date_ended = $_POST['proj_date_ended'];
    $proj_budget = $_POST['proj_budget'];
    $proj_manager_emp_no = $_POST['proj_manager_emp_no'];
	$dept_name = $_POST['dept_name'];
    $emp_no = $_POST['emp_no'];
	$emp_proj_role = $_POST['emp_proj_role'];
	$time_spent_months = $_POST['time_spent_months'];


    $query = "INSERT INTO company_db.project VALUES ('$project_no', '$proj_date_started','$proj_date_ended','$proj_budget', '$proj_manager_emp_no')";
    $query2 = "INSERT INTO company_db.dept_proj_history VALUES ('$project_no', '$dept_name')";
    $query3 = " INSERT INTO company_db.emp_proj_history VALUES( '$emp_no' , '$project_no' , '$emp_proj_role' , '$time_spent_months')";  
  
    $run = mysqli_query($conn,$query);
	$run = mysqli_query($conn,$query2);
	$run = mysqli_query($conn,$query3);
	if($run)
	{
		echo '< script type="text/javascript">alert("Values inserted successfully")</script>';
	}
    
    #echo "<script type='text/javascript'>alert('$run'); window.location.href=\"create.php\";</script>";


    if($run){
        echo "<script type='text/javascript'>alert('Successfully Inserted!'); window.location.href=\"index.html\";</script>";
    }
    else{
        echo "Error: " . $query . "<br>" . mysqli_error($conn);
    }


    }
?>