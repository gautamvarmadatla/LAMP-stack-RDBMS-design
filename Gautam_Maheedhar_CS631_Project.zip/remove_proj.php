<!DOCTYPE html>
<html>
<body>

<center><h2 style="font-family: 'Courier New';">Delete Project</h2><br><br><br><br><br><br>

<form action="remove_proj_php.php" method = "POST">
	<label for="proj_no"><b>Project Number</b></label>
      <input type="text" placeholder="Enter Project number" name="proj_no" required> <br> <br> <br><br>
      
      <div class="clearfix">
        <button class=button type="button" onclick="window.location.href='index.html'" class="cancelbtn"><b> Cancel </b> </button>
        <button class=button type="submit" name = "submit" class="signupbtn"><b> Remove </b> </button>
      </div>
</div>
</form>
</center> 
</body>
</html>